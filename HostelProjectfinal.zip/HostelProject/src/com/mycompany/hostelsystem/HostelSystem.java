/*
 * Complete Hostel & Mess Management System
 */
package com.mycompany.hostelsystem;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

/* ---------------------- STUDENT CLASS ---------------------- */
class Student implements Serializable {
    String name;
    String username;
    String password;

    Student(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
    }
}

/* ---------------------- COMPLAINT CLASS ---------------------- */
class Complaint implements Serializable {
    String from; // sender (Student)
    String to;   // recipient (Admin)
    String message;
    String reply; // admin reply

    Complaint(String from, String to, String message) {
        this.from = from;
        this.to = to;
        this.message = message;
        this.reply = "";
    }
}

/* ---------------------- NEW DATA MODELS ---------------------- */
class Allotment implements Serializable {
    String username;
    String hostel;
    String room;
    String status; // Approved / Pending

    Allotment(String username, String hostel, String room, String status) {
        this.username = username;
        this.hostel = hostel;
        this.room = room;
        this.status = status;
    }
}

class FeeRecord implements Serializable {
    String username;
    double amountDue;
    boolean paid;

    FeeRecord(String username, double amountDue) {
        this.username = username;
        this.amountDue = amountDue;
        this.paid = false;
    }
}

class Profile implements Serializable {
    String username;
    String phone;
    String email;
    String address;
    String year;
    String department;

    Profile(String username) {
        this.username = username;
        this.phone = "";
        this.email = "";
        this.address = "";
        this.year = "";
        this.department = "";
    }
}

class LeaveApplication implements Serializable {
    String id;
    String username;
    String reason;
    String fromDate;
    String toDate;
    String status; // Pending / Approved / Rejected
    String adminReply;

    LeaveApplication(String id, String username, String reason, String fromDate, String toDate) {
        this.id = id;
        this.username = username;
        this.reason = reason;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.status = "Pending";
        this.adminReply = "";
    }
}

class VisitorEntry implements Serializable {
    String username; // who registered visitor
    String visitorName;
    String dateTime;

    VisitorEntry(String username, String visitorName, String dateTime) {
        this.username = username;
        this.visitorName = visitorName;
        this.dateTime = dateTime;
    }
}

class AttendanceRecord implements Serializable {
    String username;
    int presentDays;
    int totalDays;

    AttendanceRecord(String username) {
        this.username = username;
        this.presentDays = 0;
        this.totalDays = 0;
    }

    double getPercentage() {
        if (totalDays == 0) return 0.0;
        return (presentDays * 100.0) / totalDays;
    }
}

/* ---------------------- MANAGERS (persistence helpers) ---------------------- */
class ComplaintManager {
    static void saveComplaints(ArrayList<Complaint> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("complaints.dat"));
        out.writeObject(list);
        out.close();
    }

    static ArrayList<Complaint> loadComplaints() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("complaints.dat"));
            ArrayList<Complaint> list = (ArrayList<Complaint>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class AllotmentManager {
    static void saveAllotments(ArrayList<Allotment> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("allotments.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<Allotment> loadAllotments() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("allotments.dat"));
            ArrayList<Allotment> list = (ArrayList<Allotment>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class FeeManager {
    static void saveFees(ArrayList<FeeRecord> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("fees.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<FeeRecord> loadFees() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("fees.dat"));
            ArrayList<FeeRecord> list = (ArrayList<FeeRecord>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class ProfileManager {
    static void saveProfiles(ArrayList<Profile> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("profiles.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<Profile> loadProfiles() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("profiles.dat"));
            ArrayList<Profile> list = (ArrayList<Profile>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class LeaveManager {
    static void saveLeaves(ArrayList<LeaveApplication> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("leaves.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<LeaveApplication> loadLeaves() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("leaves.dat"));
            ArrayList<LeaveApplication> list = (ArrayList<LeaveApplication>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class VisitorManager {
    static void saveVisitors(ArrayList<VisitorEntry> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("visitors.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<VisitorEntry> loadVisitors() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("visitors.dat"));
            ArrayList<VisitorEntry> list = (ArrayList<VisitorEntry>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

class AttendanceManager {
    static void saveAttendance(ArrayList<AttendanceRecord> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("attendance.dat"));
        out.writeObject(list);
        out.close();
    }
    static ArrayList<AttendanceRecord> loadAttendance() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("attendance.dat"));
            ArrayList<AttendanceRecord> list = (ArrayList<AttendanceRecord>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

/* ---------------------- UI HELPER (PROFESSIONAL COLORS) ---------------------- */
class UI {
    // Professional theme
    // Background: #F4F7FC
    // Header: #1A385A
    // Sidebar: #112C45
    // Button: #2B6CB0
    // Button hover: #1A4E80 (not used programmatically here)
    // Text dark: #333333
    static Color bg = new Color(244, 247, 252);         // #F4F7FC
    static Color headerColor = new Color(26, 56, 90);   // #1A385A
    static Color sidebarBg = new Color(17, 44, 69);     // #112C45
    static Color btnColor = new Color(43, 108, 176);    // #2B6CB0
    static Color sidebarBtn = new Color(28, 59, 85);    // slightly lighter than sidebar
    static Color textDark = new Color(51, 51, 51);      // #333333

    static void styleButton(JButton btn) {
        btn.setBackground(btnColor);
        btn.setForeground(Color.white);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
    }

    static void styleSidebarButton(JButton btn) {
        btn.setBackground(sidebarBtn);
        btn.setForeground(Color.white);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
    }

    static JPanel header(String text) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(headerColor);
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 20));
        l.setForeground(Color.white);
        l.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        p.add(l, BorderLayout.WEST);
        return p;
    }
}

/* ---------------------- MAIN CLASS ---------------------- */
public class HostelSystem {
    public static void main(String[] args) {
        // ensure data files exist (create if missing)
        try { StudentRegistration.loadStudents(); } catch (Exception ignored) {}
        try { ComplaintManager.loadComplaints(); } catch (Exception ignored) {}
        try { AllotmentManager.loadAllotments(); } catch (Exception ignored) {}
        try { FeeManager.loadFees(); } catch (Exception ignored) {}
        try { ProfileManager.loadProfiles(); } catch (Exception ignored) {}
        try { LeaveManager.loadLeaves(); } catch (Exception ignored) {}
        try { VisitorManager.loadVisitors(); } catch (Exception ignored) {}
        try { AttendanceManager.loadAttendance(); } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            UI.styleButton(new JButton()); // preload fonts/look
            new HomePage();
        });
    }
}

/* ---------------------- HOME PAGE ---------------------- */
class HomePage extends JFrame {
    JButton adminLoginBtn, studentLoginBtn, registerBtn;

    HomePage() {
        setTitle("Hostel Allotment System");
        setSize(420, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(UI.bg);

        JPanel header = UI.header("Hostel Allotment System");

        adminLoginBtn = new JButton("Admin Login");
        studentLoginBtn = new JButton("Student Login");
        registerBtn = new JButton("Student Registration");

        UI.styleButton(adminLoginBtn);
        UI.styleButton(studentLoginBtn);
        UI.styleButton(registerBtn);

        adminLoginBtn.addActionListener(e -> new AdminLogin());
        studentLoginBtn.addActionListener(e -> new StudentLogin());
        registerBtn.addActionListener(e -> new StudentRegistration());

        JPanel center = new JPanel(new GridLayout(3, 1, 10, 10));
        center.setBackground(UI.bg);
        center.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        center.add(adminLoginBtn);
        center.add(studentLoginBtn);
        center.add(registerBtn);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        setVisible(true);
    }
}
