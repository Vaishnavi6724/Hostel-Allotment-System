/*
 * Student-related classes for Hostel Management System
 */
package com.mycompany.hostelsystem;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

/* ---------------------- STUDENT REGISTRATION ---------------------- */
class StudentRegistration extends JFrame {
    JTextField nameField, usernameField;
    JPasswordField passwordField;
    JButton registerBtn, showPassBtn;
    boolean visible = false;

    StudentRegistration() {
        setTitle("Student Registration");
        setSize(500, 380);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UI.bg);

        JPanel header = UI.header("Student Registration");

        JLabel nameLbl = new JLabel("Full Name:");
        JLabel usernameLbl = new JLabel("Username:");
        JLabel passwordLbl = new JLabel("Password:");

        nameLbl.setForeground(UI.textDark);
        usernameLbl.setForeground(UI.textDark);
        passwordLbl.setForeground(UI.textDark);

        nameField = new JTextField();
        usernameField = new JTextField();
        passwordField = new JPasswordField();

        registerBtn = new JButton("Register");
        UI.styleButton(registerBtn);

        showPassBtn = new JButton("Show");
        showPassBtn.setFocusPainted(false);
        showPassBtn.addActionListener(e -> togglePassword());

        registerBtn.addActionListener(e -> registerStudent());

        JPanel form = new JPanel(new GridLayout(5, 3, 10, 10));
        form.setBackground(UI.bg);
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(nameLbl); form.add(nameField); form.add(new JLabel());
        form.add(usernameLbl); form.add(usernameField); form.add(new JLabel());
        form.add(passwordLbl); form.add(passwordField); form.add(showPassBtn);
        form.add(new JLabel()); form.add(registerBtn); form.add(new JLabel());
        form.add(new JLabel()); form.add(new JLabel()); form.add(new JLabel());

        add(header, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);

        setVisible(true);
    }

    void togglePassword() {
        visible = !visible;
        passwordField.setEchoChar(visible ? (char) 0 : '•');
        showPassBtn.setText(visible ? "Hide" : "Show");
    }

    boolean isValidPassword(String pass) {
        String regex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&+=!?]).{6,}$";
        return Pattern.matches(regex, pass);
    }

    void registerStudent() {
        String name = nameField.getText().trim();
        String username = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        if (name.isEmpty() || username.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        if (!isValidPassword(pass)) {
            JOptionPane.showMessageDialog(this,
                    "Password must contain:\n• Uppercase\n• Lowercase\n• Special Symbol\n• Min 6 characters");
            return;
        }

        try {
            ArrayList<Student> list = loadStudents();
            // check username unique
            for (Student s : list) if (s.username.equalsIgnoreCase(username)) {
                JOptionPane.showMessageDialog(this, "Username already exists!");
                return;
            }
            list.add(new Student(name, username, pass));
            saveStudents(list);

            // create default profile, fee, attendance record
            ArrayList<Profile> profiles = ProfileManager.loadProfiles();
            profiles.add(new Profile(username));
            ProfileManager.saveProfiles(profiles);

            ArrayList<FeeRecord> fees = FeeManager.loadFees();
            fees.add(new FeeRecord(username, 0.0));
            FeeManager.saveFees(fees);

            ArrayList<AttendanceRecord> attendance = AttendanceManager.loadAttendance();
            attendance.add(new AttendanceRecord(username));
            AttendanceManager.saveAttendance(attendance);

            JOptionPane.showMessageDialog(this, "Registration Successful!");
            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving student data.");
            ex.printStackTrace();
        }
    }

    static void saveStudents(ArrayList<Student> list) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("students.dat"));
        out.writeObject(list);
        out.close();
    }

    static ArrayList<Student> loadStudents() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("students.dat"));
            ArrayList<Student> list = (ArrayList<Student>) in.readObject();
            in.close();
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}

/* ---------------------- STUDENT LOGIN ---------------------- */
class StudentLogin extends JFrame {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginBtn, showPassBtn;
    boolean visible = false;

    StudentLogin() {
        setTitle("Student Login");
        setSize(420, 300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UI.bg);

        JPanel header = UI.header("Student Login");

        JLabel usernameLbl = new JLabel("Username:");
        JLabel passwordLbl = new JLabel("Password:");

        usernameLbl.setForeground(UI.textDark);
        passwordLbl.setForeground(UI.textDark);

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        loginBtn = new JButton("Login");
        UI.styleButton(loginBtn);

        showPassBtn = new JButton("Show");
        showPassBtn.addActionListener(e -> togglePassword());

        loginBtn.addActionListener(e -> loginStudent());

        JPanel form = new JPanel(new GridLayout(4, 3, 10, 10));
        form.setBackground(UI.bg);
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(usernameLbl); form.add(usernameField); form.add(new JLabel());
        form.add(passwordLbl); form.add(passwordField); form.add(showPassBtn);
        form.add(new JLabel()); form.add(loginBtn); form.add(new JLabel());
        form.add(new JLabel()); form.add(new JLabel()); form.add(new JLabel());

        add(header, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);

        setVisible(true);
    }

    void togglePassword() {
        visible = !visible;
        passwordField.setEchoChar(visible ? (char) 0 : '•');
        showPassBtn.setText(visible ? "Hide" : "Show");
    }

    void loginStudent() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        ArrayList<Student> list = StudentRegistration.loadStudents();

        for (Student s : list) {
            if (s.username.equals(user) && s.password.equals(pass)) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                new StudentDashboard(s.name, s.username);
                dispose();
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Invalid Username or Password!");
    }
}

/* ---------------------- STUDENT DASHBOARD (PROFESSIONAL LAYOUT) ---------------------- */
class StudentDashboard extends JFrame {
    String username;
    String displayName;

    JPanel sidebar;
    JPanel headerPanel;
    JPanel contentPanel;
    CardLayout card;

    StudentDashboard(String displayName, String username) {
        this.displayName = displayName;
        this.username = username;

        setTitle("Student Dashboard - " + displayName);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UI.bg);
        setLayout(new BorderLayout());

        // Header
        headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UI.headerColor);
        JLabel title = new JLabel("Welcome, " + displayName);
        title.setForeground(Color.white);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        headerPanel.add(title, BorderLayout.WEST);

        // Sidebar
        sidebar = new JPanel();
        sidebar.setLayout(new GridLayout(10, 1, 6, 6));
        sidebar.setBackground(UI.sidebarBg);
        sidebar.setPreferredSize(new Dimension(220, 600));
        sidebar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] items = {"Home", "Hostel Allotment", "Fee Payment", "Profile", "Leave Application", "Visitor Entry", "Attendance", "Complaints", "Logout"};
        for (String it : items) {
            JButton b = new JButton("  " + it);
            UI.styleSidebarButton(b);
            sidebar.add(b);
            b.addActionListener(e -> {
                if (it.equals("Logout")) {
                    dispose();
                    new HomePage();
                } else {
                    card.show(contentPanel, it);
                }
            });
        }

        // Content with CardLayout
        card = new CardLayout();
        contentPanel = new JPanel(card);
        contentPanel.setBackground(Color.white);

        // Home Panel
        JPanel homePanel = new JPanel(new BorderLayout());
        homePanel.setBackground(Color.white);
        JLabel homeLabel = new JLabel("<html><h2>Student Dashboard</h2><p>Select an option from the left menu.</p></html>");
        homeLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        homePanel.add(homeLabel, BorderLayout.NORTH);

        // Allotment Panel
        JPanel allotPanel = new JPanel(new BorderLayout());
        allotPanel.setBackground(Color.white);
        JPanel apTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        apTop.setBackground(Color.white);
        JButton viewAllotBtn = new JButton("View Allotment");
        UI.styleButton(viewAllotBtn);
        apTop.add(viewAllotBtn);
        allotPanel.add(apTop, BorderLayout.NORTH);
        viewAllotBtn.addActionListener(e -> viewAllotment(username));
        allotPanel.add(new JLabel("Allotment info will show via dialog."), BorderLayout.CENTER);

        // Fee Panel
        JPanel feePanel = new JPanel(new BorderLayout());
        feePanel.setBackground(Color.white);
        JPanel feeTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        feeTop.setBackground(Color.white);
        JButton viewFeeBtn = new JButton("View / Pay Fees (simulate)");
        UI.styleButton(viewFeeBtn);
        feeTop.add(viewFeeBtn);
        feePanel.add(feeTop, BorderLayout.NORTH);
        viewFeeBtn.addActionListener(e -> openFees(username));
        feePanel.add(new JLabel("Fees actions via dialog."), BorderLayout.CENTER);

        // Profile Panel
        JPanel profPanel = new JPanel(new BorderLayout());
        profPanel.setBackground(Color.white);
        JPanel profTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        profTop.setBackground(Color.white);
        JButton editProfBtn = new JButton("View / Edit Profile");
        UI.styleButton(editProfBtn);
        profTop.add(editProfBtn);
        profPanel.add(profTop, BorderLayout.NORTH);
        editProfBtn.addActionListener(e -> openProfile(username));
        profPanel.add(new JLabel("Profile edit via dialog."), BorderLayout.CENTER);

        // Leave Panel
        JPanel leavePanel = new JPanel(new BorderLayout());
        leavePanel.setBackground(Color.white);
        JPanel leaveTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leaveTop.setBackground(Color.white);
        JButton applyLeaveBtn = new JButton("Apply Leave");
        UI.styleButton(applyLeaveBtn);
        leaveTop.add(applyLeaveBtn);
        leavePanel.add(leaveTop, BorderLayout.NORTH);
        applyLeaveBtn.addActionListener(e -> applyLeave(username));
        leavePanel.add(new JLabel("Apply leave via dialog."), BorderLayout.CENTER);

        // Visitor Panel
        JPanel visitorPanel = new JPanel(new BorderLayout());
        visitorPanel.setBackground(Color.white);
        JPanel visTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        visTop.setBackground(Color.white);
        JButton regVisBtn = new JButton("Register Visitor");
        UI.styleButton(regVisBtn);
        visTop.add(regVisBtn);
        visitorPanel.add(visTop, BorderLayout.NORTH);
        regVisBtn.addActionListener(e -> registerVisitor(username));
        visitorPanel.add(new JLabel("Register visitor via dialog."), BorderLayout.CENTER);

        // Attendance Panel
        JPanel attPanel = new JPanel(new BorderLayout());
        attPanel.setBackground(Color.white);
        JPanel attTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        attTop.setBackground(Color.white);
        JButton viewAttBtn = new JButton("View Attendance");
        UI.styleButton(viewAttBtn);
        attTop.add(viewAttBtn);
        attPanel.add(attTop, BorderLayout.NORTH);
        viewAttBtn.addActionListener(e -> viewAttendance(username));
        attPanel.add(new JLabel("Attendance via dialog."), BorderLayout.CENTER);

        // Complaints Panel
        JPanel compPanel = new JPanel(new BorderLayout());
        compPanel.setBackground(Color.white);
        JPanel compTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        compTop.setBackground(Color.white);
        JButton sendCompBtn = new JButton("Send Complaint");
        JButton viewRepBtn = new JButton("View Replies");
        UI.styleButton(sendCompBtn); UI.styleButton(viewRepBtn);
        compTop.add(sendCompBtn); compTop.add(viewRepBtn);
        compPanel.add(compTop, BorderLayout.NORTH);
        sendCompBtn.addActionListener(e -> sendComplaint(username));
        viewRepBtn.addActionListener(e -> viewReplies(username));
        compPanel.add(new JLabel("Complaints via dialog."), BorderLayout.CENTER);

        // Add cards
        contentPanel.add(homePanel, "Home");
        contentPanel.add(allotPanel, "Hostel Allotment");
        contentPanel.add(feePanel, "Fee Payment");
        contentPanel.add(profPanel, "Profile");
        contentPanel.add(leavePanel, "Leave Application");
        contentPanel.add(visitorPanel, "Visitor Entry");
        contentPanel.add(attPanel, "Attendance");
        contentPanel.add(compPanel, "Complaints");

        // layout
        add(headerPanel, BorderLayout.NORTH);
        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        // default
        card.show(contentPanel, "Home");

        setVisible(true);
    }

    // existing complaint functions unchanged
    void sendComplaint(String studentName) {
        String message = JOptionPane.showInputDialog(this, "Enter your complaint to Admin:");
        if (message != null && !message.trim().isEmpty()) {
            try {
                ArrayList<Complaint> list = ComplaintManager.loadComplaints();
                list.add(new Complaint(studentName, "Admin", message));
                ComplaintManager.saveComplaints(list);
                JOptionPane.showMessageDialog(this, "Complaint sent successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving complaint.");
                ex.printStackTrace();
            }
        }
    }

    void viewReplies(String studentName) {
        ArrayList<Complaint> list = ComplaintManager.loadComplaints();
        StringBuilder sb = new StringBuilder();
        boolean found = false;

        for (Complaint c : list) {
            if (c.from.equals(studentName) && !c.reply.isEmpty()) {
                sb.append("Admin Reply: " + c.reply + "\n\n");
                found = true;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "No replies from Admin yet.");
            return;
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(450, 250));

        JOptionPane.showMessageDialog(this, scrollPane, "Replies from Admin", JOptionPane.INFORMATION_MESSAGE);
    }

    /* --------- New Feature: View Allotment --------- */
    void viewAllotment(String username) {
        ArrayList<Allotment> list = AllotmentManager.loadAllotments();
        for (Allotment a : list) {
            if (a.username.equalsIgnoreCase(username)) {
                String info = "Hostel: " + a.hostel + "\nRoom: " + a.room + "\nStatus: " + a.status;
                JOptionPane.showMessageDialog(this, info, "Allotment Status", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No allotment found (Pending).", "Allotment Status", JOptionPane.INFORMATION_MESSAGE);
    }

    /* --------- New Feature: Profile (view/update + change password) --------- */
    void openProfile(String username) {
        ArrayList<Profile> profiles = ProfileManager.loadProfiles();
        Profile p = null;
        for (Profile pr : profiles) if (pr.username.equalsIgnoreCase(username)) p = pr;
        if (p == null) {
            p = new Profile(username);
            profiles.add(p);
        }

        JTextField phoneF = new JTextField(p.phone);
        JTextField emailF = new JTextField(p.email);
        JTextField addrF = new JTextField(p.address);
        JTextField yearF = new JTextField(p.year);
        JTextField deptF = new JTextField(p.department);

        Object[] fields = {
                "Phone:", phoneF,
                "Email:", emailF,
                "Address:", addrF,
                "Year:", yearF,
                "Department:", deptF
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "Your Profile", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            p.phone = phoneF.getText().trim();
            p.email = emailF.getText().trim();
            p.address = addrF.getText().trim();
            p.year = yearF.getText().trim();
            p.department = deptF.getText().trim();
            try {
                ProfileManager.saveProfiles(profiles);
                JOptionPane.showMessageDialog(this, "Profile updated!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving profile.");
                ex.printStackTrace();
            }
        }

        // Change password option
        int ch = JOptionPane.showConfirmDialog(this, "Do you want to change password?", "Change Password", JOptionPane.YES_NO_OPTION);
        if (ch == JOptionPane.YES_OPTION) {
            String oldPass = JOptionPane.showInputDialog(this, "Enter current password:");
            if (oldPass == null) return;
            ArrayList<Student> studs = StudentRegistration.loadStudents();
            for (Student s : studs) {
                if (s.username.equalsIgnoreCase(username)) {
                    if (!s.password.equals(oldPass)) {
                        JOptionPane.showMessageDialog(this, "Current password incorrect!");
                        return;
                    }
                    String newPass = JOptionPane.showInputDialog(this, "Enter new password (must contain uppercase, lowercase, special, min 6):");
                    if (newPass == null) return;
                    String regex = "^(?=.[A-Z])(?=.[a-z])(?=.*[@#$%^&+=!?]).{6,}$";
                    if (!Pattern.matches(regex, newPass)) {
                        JOptionPane.showMessageDialog(this, "Password does not meet requirements.");
                        return;
                    }
                    s.password = newPass;
                    try {
                        StudentRegistration.saveStudents(studs);
                        JOptionPane.showMessageDialog(this, "Password changed successfully!");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Error saving password.");
                        ex.printStackTrace();
                    }
                    return;
                }
            }
        }
    }

    /* --------- New Feature: Fees --------- */
    void openFees(String username) {
        ArrayList<FeeRecord> fees = FeeManager.loadFees();
        FeeRecord fr = null;
        for (FeeRecord f : fees) if (f.username.equalsIgnoreCase(username)) fr = f;
        if (fr == null) {
            fr = new FeeRecord(username, 0.0);
            fees.add(fr);
        }

        String info = String.format("Amount Due: ₹ %.2f\nPaid: %s", fr.amountDue, fr.paid ? "Yes" : "No");
        int option = JOptionPane.showConfirmDialog(this, info + "\n\nDo you want to mark as Paid? (simulation)", "Fees", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            if (fr.paid) {
                JOptionPane.showMessageDialog(this, "Already marked paid.");
                return;
            }
            fr.paid = true;
            try {
                FeeManager.saveFees(fees);
                JOptionPane.showMessageDialog(this, "Payment marked as paid (simulation).");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving fee record.");
                ex.printStackTrace();
            }
        }
    }

    /* --------- New Feature: Leave Application --------- */
    void applyLeave(String username) {
        JTextField reasonF = new JTextField();
        JTextField fromF = new JTextField("YYYY-MM-DD");
        JTextField toF = new JTextField("YYYY-MM-DD");
        Object[] fields = {
                "Reason:", reasonF,
                "From (date):", fromF,
                "To (date):", toF
        };
        int opt = JOptionPane.showConfirmDialog(this, fields, "Apply for Leave", JOptionPane.OK_CANCEL_OPTION);
        if (opt == JOptionPane.OK_OPTION) {
            String reason = reasonF.getText().trim();
            String from = fromF.getText().trim();
            String to = toF.getText().trim();
            if (reason.isEmpty() || from.isEmpty() || to.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields required.");
                return;
            }
            try {
                ArrayList<LeaveApplication> leaves = LeaveManager.loadLeaves();
                String id = "L" + (new Date().getTime());
                leaves.add(new LeaveApplication(id, username, reason, from, to));
                LeaveManager.saveLeaves(leaves);
                JOptionPane.showMessageDialog(this, "Leave applied successfully. ID: " + id);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving leave.");
                ex.printStackTrace();
            }
        }
    }

    /* --------- New Feature: Visitor Entry --------- */
    void registerVisitor(String username) {
        String visitor = JOptionPane.showInputDialog(this, "Enter visitor name:");
        if (visitor == null || visitor.trim().isEmpty()) return;
        String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
        try {
            ArrayList<VisitorEntry> vs = VisitorManager.loadVisitors();
            vs.add(new VisitorEntry(username, visitor.trim(), dateTime));
            VisitorManager.saveVisitors(vs);
            JOptionPane.showMessageDialog(this, "Visitor registered at " + dateTime);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving visitor.");
            ex.printStackTrace();
        }
    }

    /* --------- New Feature: Attendance View --------- */
    void viewAttendance(String username) {
        ArrayList<AttendanceRecord> atts = AttendanceManager.loadAttendance();
        for (AttendanceRecord a : atts) {
            if (a.username.equalsIgnoreCase(username)) {
                String msg = String.format("Present Days: %d\nTotal Days: %d\nAttendance: %.2f%%", a.presentDays, a.totalDays, a.getPercentage());
                JOptionPane.showMessageDialog(this, msg, "Attendance", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No attendance record found.");
    }
}

