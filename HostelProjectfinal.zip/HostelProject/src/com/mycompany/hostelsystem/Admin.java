/*
 * Admin-related classes for Hostel Management System
 */
package com.mycompany.hostelsystem;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

/* ---------------------- ADMIN LOGIN ---------------------- */
class AdminLogin extends JFrame {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginBtn, showPassBtn;
    boolean visible = false;

    AdminLogin() {
        setTitle("Admin Login");
        setSize(420, 300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UI.bg);

        JPanel header = UI.header("Admin Login");

        JLabel usernameLbl = new JLabel("Admin Username:");
        JLabel passwordLbl = new JLabel("Password:");

        usernameLbl.setForeground(UI.textDark);
        passwordLbl.setForeground(UI.textDark);

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        loginBtn = new JButton("Login");
        UI.styleButton(loginBtn);

        showPassBtn = new JButton("Show");
        showPassBtn.addActionListener(e -> togglePassword());

        loginBtn.addActionListener(e -> loginAdmin());

        JPanel form = new JPanel(new GridLayout(4, 3, 10, 10));
        form.setBackground(UI.bg);
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(usernameLbl); form.add(usernameField); form.add(new JLabel());
        form.add(passwordLbl); form.add(passwordField); form.add(showPassBtn);
        form.add(new JLabel()); form.add(loginBtn); form.add(new JLabel());
        form.add(new JLabel()); form.add(new JLabel()); form.add(new JLabel());

        add(header, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);

        setVisible(true);
    }

    void togglePassword() {
        visible = !visible;
        passwordField.setEchoChar(visible ? (char) 0 : '•');
        showPassBtn.setText(visible ? "Hide" : "Show");
    }

    void loginAdmin() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        if (user.equals("admin") && pass.equals("Admin@123")) {
            JOptionPane.showMessageDialog(this, "Admin Login Successful!");
            new AdminDashboard();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Admin Credentials!");
        }
    }
}

/* ---------------------- ADMIN DASHBOARD (PROFESSIONAL LAYOUT) ---------------------- */
class AdminDashboard extends JFrame {
    JPanel sidebar;
    JPanel headerPanel;
    JPanel contentPanel;
    CardLayout card;

    AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UI.bg);
        setLayout(new BorderLayout());

        // Header
        headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UI.headerColor);
        JLabel title = new JLabel("Welcome Admin");
        title.setForeground(Color.white);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        headerPanel.add(title, BorderLayout.WEST);

        // Sidebar
        sidebar = new JPanel();
        sidebar.setLayout(new GridLayout(10, 1, 6, 6));
        sidebar.setBackground(UI.sidebarBg);
        sidebar.setPreferredSize(new Dimension(240, 600));
        sidebar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] items = {"Home", "Manage Students", "Allot Hostel", "Set Fees", "Manage Leaves", "Visitor Logs", "Attendance", "Complaints", "Logout"};
        for (String it : items) {
            JButton b = new JButton("  " + it);
            UI.styleSidebarButton(b);
            sidebar.add(b);
            b.addActionListener(e -> {
                if (it.equals("Logout")) {
                    dispose();
                    new HomePage();
                } else {
                    card.show(contentPanel, it);
                }
            });
        }

        // Content with CardLayout
        card = new CardLayout();
        contentPanel = new JPanel(card);
        contentPanel.setBackground(Color.white);

        // Home panel
        JPanel homePanel = new JPanel(new BorderLayout());
        homePanel.setBackground(Color.white);
        homePanel.add(new JLabel("<html><h2>Admin Dashboard</h2><p>Select an option from the left menu.</p></html>"), BorderLayout.NORTH);

        // Manage Students panel
        JPanel managePanel = new JPanel(new BorderLayout());
        managePanel.setBackground(Color.white);
        JPanel mTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        mTop.setBackground(Color.white);
        JButton addBtn = new JButton("Add Student");
        JButton delBtn = new JButton("Delete Student");
        JButton searchBtn = new JButton("Search Student");
        JButton viewAllBtn = new JButton("View All Students");
        UI.styleButton(addBtn); UI.styleButton(delBtn); UI.styleButton(searchBtn); UI.styleButton(viewAllBtn);
        mTop.add(addBtn); mTop.add(delBtn); mTop.add(searchBtn); mTop.add(viewAllBtn);
        managePanel.add(mTop, BorderLayout.NORTH);
        addBtn.addActionListener(e -> addStudent());
        delBtn.addActionListener(e -> deleteStudent());
        searchBtn.addActionListener(e -> searchStudent());
        viewAllBtn.addActionListener(e -> viewAllStudents());

        // Allotment panel
        JPanel allotPanel = new JPanel(new BorderLayout());
        allotPanel.setBackground(Color.white);
        JPanel aTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        aTop.setBackground(Color.white);
        JButton setAllotBtn = new JButton("Set Allotment");
        UI.styleButton(setAllotBtn);
        aTop.add(setAllotBtn);
        allotPanel.add(aTop, BorderLayout.NORTH);
        setAllotBtn.addActionListener(e -> setAllotment());

        // Fees panel
        JPanel feesPanel = new JPanel(new BorderLayout());
        feesPanel.setBackground(Color.white);
        JPanel fTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fTop.setBackground(Color.white);
        JButton setFeesBtn = new JButton("Set Fees for Student");
        UI.styleButton(setFeesBtn);
        fTop.add(setFeesBtn);
        feesPanel.add(fTop, BorderLayout.NORTH);
        setFeesBtn.addActionListener(e -> setFees());

        // Leaves panel
        JPanel leavesPanel = new JPanel(new BorderLayout());
        leavesPanel.setBackground(Color.white);
        JPanel lTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lTop.setBackground(Color.white);
        JButton manageLeavesBtn = new JButton("Manage Leaves");
        UI.styleButton(manageLeavesBtn);
        lTop.add(manageLeavesBtn);
        leavesPanel.add(lTop, BorderLayout.NORTH);
        manageLeavesBtn.addActionListener(e -> manageLeaves());

        // Visitor logs
        JPanel visitorPanel = new JPanel(new BorderLayout());
        visitorPanel.setBackground(Color.white);
        JPanel vTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        vTop.setBackground(Color.white);
        JButton viewVisitorsBtn = new JButton("View Visitors");
        UI.styleButton(viewVisitorsBtn);
        vTop.add(viewVisitorsBtn);
        visitorPanel.add(vTop, BorderLayout.NORTH);
        viewVisitorsBtn.addActionListener(e -> viewVisitors());

        // Attendance panel
        JPanel attendancePanel = new JPanel(new BorderLayout());
        attendancePanel.setBackground(Color.white);
        JPanel atTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        atTop.setBackground(Color.white);
        JButton markAttBtn = new JButton("Mark Attendance");
        UI.styleButton(markAttBtn);
        atTop.add(markAttBtn);
        attendancePanel.add(atTop, BorderLayout.NORTH);
        markAttBtn.addActionListener(e -> markAttendance());

        // Complaints panel
        JPanel complaintsPanel = new JPanel(new BorderLayout());
        complaintsPanel.setBackground(Color.white);
        JPanel cTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cTop.setBackground(Color.white);
        JButton viewCompBtn = new JButton("View Complaints");
        UI.styleButton(viewCompBtn);
        cTop.add(viewCompBtn);
        complaintsPanel.add(cTop, BorderLayout.NORTH);
        viewCompBtn.addActionListener(e -> viewComplaints());

        // add cards
        contentPanel.add(homePanel, "Home");
        contentPanel.add(managePanel, "Manage Students");
        contentPanel.add(allotPanel, "Allot Hostel");
        contentPanel.add(feesPanel, "Set Fees");
        contentPanel.add(leavesPanel, "Manage Leaves");
        contentPanel.add(visitorPanel, "Visitor Logs");
        contentPanel.add(attendancePanel, "Attendance");
        contentPanel.add(complaintsPanel, "Complaints");

        add(headerPanel, BorderLayout.NORTH);
        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        card.show(contentPanel, "Home");
        setVisible(true);
    }

    /* ---------- Methods reused from earlier (adapted to panels) ---------- */

    /* ---------- Manage Students helpers (used by buttons) ---------- */
    void addStudent() {
        String name = JOptionPane.showInputDialog(this, "Student full name:");
        if (name == null) return;
        String uname = JOptionPane.showInputDialog(this, "Username:");
        if (uname == null) return;
        String pass = JOptionPane.showInputDialog(this, "Password (must meet rules):");
        if (pass == null) return;
        String regex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&+=!?]).{6,}$";
        if (!Pattern.matches(regex, pass)) {
            JOptionPane.showMessageDialog(this, "Password doesn't meet requirements.");
            return;
        }
        try {
            ArrayList<Student> studs = StudentRegistration.loadStudents();
            for (Student s : studs) if (s.username.equalsIgnoreCase(uname)) {
                JOptionPane.showMessageDialog(this, "Username already exists.");
                return;
            }
            studs.add(new Student(name, uname, pass));
            StudentRegistration.saveStudents(studs);
            // create default profile/fee/attendance
            ArrayList<Profile> profiles = ProfileManager.loadProfiles();
            profiles.add(new Profile(uname));
            ProfileManager.saveProfiles(profiles);

            ArrayList<FeeRecord> fees = FeeManager.loadFees();
            fees.add(new FeeRecord(uname, 0.0));
            FeeManager.saveFees(fees);

            ArrayList<AttendanceRecord> atts = AttendanceManager.loadAttendance();
            atts.add(new AttendanceRecord(uname));
            AttendanceManager.saveAttendance(atts);

            JOptionPane.showMessageDialog(this, "Student added.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding student.");
            ex.printStackTrace();
        }
    }

    void deleteStudent() {
        String uname = JOptionPane.showInputDialog(this, "Enter username to delete:");
        if (uname == null) return;
        try {
            ArrayList<Student> studs = StudentRegistration.loadStudents();
            boolean removed = studs.removeIf(s -> s.username.equalsIgnoreCase(uname));
            if (removed) {
                StudentRegistration.saveStudents(studs);
                // remove related records
                ArrayList<Profile> profiles = ProfileManager.loadProfiles();
                profiles.removeIf(p -> p.username.equalsIgnoreCase(uname));
                ProfileManager.saveProfiles(profiles);

                ArrayList<FeeRecord> fees = FeeManager.loadFees();
                fees.removeIf(f -> f.username.equalsIgnoreCase(uname));
                FeeManager.saveFees(fees);

                ArrayList<Allotment> alls = AllotmentManager.loadAllotments();
                alls.removeIf(a -> a.username.equalsIgnoreCase(uname));
                AllotmentManager.saveAllotments(alls);

                ArrayList<AttendanceRecord> atts = AttendanceManager.loadAttendance();
                atts.removeIf(a -> a.username.equalsIgnoreCase(uname));
                AttendanceManager.saveAttendance(atts);

                JOptionPane.showMessageDialog(this, "Student deleted.");
            } else {
                JOptionPane.showMessageDialog(this, "Student not found.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting student.");
            ex.printStackTrace();
        }
    }

    void searchStudent() {
        String uname = JOptionPane.showInputDialog(this, "Enter username to search:");
        if (uname == null) return;
        ArrayList<Student> studs = StudentRegistration.loadStudents();
        for (Student s : studs) {
            if (s.username.equalsIgnoreCase(uname)) {
                String info = "Name: " + s.name + "\nUsername: " + s.username;
                JOptionPane.showMessageDialog(this, info, "Student Found", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Student not found.");
    }

    /* ---------- View All Students ---------- */
    void viewAllStudents() {
        try {
            ArrayList<Student> students = StudentRegistration.loadStudents();
            if (students.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No students found.");
                return;
            }

            // Load related data
            ArrayList<Profile> profiles = ProfileManager.loadProfiles();
            ArrayList<Allotment> allotments = AllotmentManager.loadAllotments();
            ArrayList<FeeRecord> fees = FeeManager.loadFees();
            ArrayList<AttendanceRecord> attendance = AttendanceManager.loadAttendance();

            // Create table with columns
            String[] columns = {"Name", "Username", "Phone", "Email", "Year", "Department", 
                              "Hostel", "Room", "Allotment Status", "Fee Due", "Fee Paid", "Attendance %"};
            
            // Create data array
            Object[][] data = new Object[students.size()][columns.length];
            
            for (int i = 0; i < students.size(); i++) {
                Student s = students.get(i);
                data[i][0] = s.name;
                data[i][1] = s.username;
                
                // Find profile
                Profile p = null;
                for (Profile prof : profiles) {
                    if (prof.username.equalsIgnoreCase(s.username)) {
                        p = prof;
                        break;
                    }
                }
                data[i][2] = (p != null && !p.phone.isEmpty()) ? p.phone : "N/A";
                data[i][3] = (p != null && !p.email.isEmpty()) ? p.email : "N/A";
                data[i][4] = (p != null && !p.year.isEmpty()) ? p.year : "N/A";
                data[i][5] = (p != null && !p.department.isEmpty()) ? p.department : "N/A";
                
                // Find allotment
                Allotment a = null;
                for (Allotment all : allotments) {
                    if (all.username.equalsIgnoreCase(s.username)) {
                        a = all;
                        break;
                    }
                }
                data[i][6] = (a != null) ? a.hostel : "N/A";
                data[i][7] = (a != null) ? a.room : "N/A";
                data[i][8] = (a != null) ? a.status : "Pending";
                
                // Find fee record
                FeeRecord f = null;
                for (FeeRecord fee : fees) {
                    if (fee.username.equalsIgnoreCase(s.username)) {
                        f = fee;
                        break;
                    }
                }
                data[i][9] = (f != null) ? String.format("₹ %.2f", f.amountDue) : "₹ 0.00";
                data[i][10] = (f != null && f.paid) ? "Yes" : "No";
                
                // Find attendance
                AttendanceRecord att = null;
                for (AttendanceRecord at : attendance) {
                    if (at.username.equalsIgnoreCase(s.username)) {
                        att = at;
                        break;
                    }
                }
                if (att != null && att.totalDays > 0) {
                    data[i][11] = String.format("%.2f%%", att.getPercentage());
                } else {
                    data[i][11] = "0.00%";
                }
            }

            // Create table
            JTable table = new JTable(data, columns);
            table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            table.setRowHeight(25);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            
            // Make table non-editable
            table.setDefaultEditor(Object.class, null);
            
            // Set column widths
            table.getColumnModel().getColumn(0).setPreferredWidth(120); // Name
            table.getColumnModel().getColumn(1).setPreferredWidth(100); // Username
            table.getColumnModel().getColumn(2).setPreferredWidth(100); // Phone
            table.getColumnModel().getColumn(3).setPreferredWidth(150); // Email
            table.getColumnModel().getColumn(4).setPreferredWidth(60);  // Year
            table.getColumnModel().getColumn(5).setPreferredWidth(120); // Department
            table.getColumnModel().getColumn(6).setPreferredWidth(100); // Hostel
            table.getColumnModel().getColumn(7).setPreferredWidth(80);  // Room
            table.getColumnModel().getColumn(8).setPreferredWidth(120); // Allotment Status
            table.getColumnModel().getColumn(9).setPreferredWidth(100); // Fee Due
            table.getColumnModel().getColumn(10).setPreferredWidth(80); // Fee Paid
            table.getColumnModel().getColumn(11).setPreferredWidth(100); // Attendance %
            
            // Create scroll pane
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setPreferredSize(new Dimension(1200, 500));
            
            // Create dialog
            JDialog dialog = new JDialog(this, "All Students Details", true);
            dialog.setSize(1250, 550);
            dialog.setLocationRelativeTo(this);
            dialog.add(scrollPane, BorderLayout.CENTER);
            
            // Add close button
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton closeBtn = new JButton("Close");
            UI.styleButton(closeBtn);
            closeBtn.addActionListener(e -> dialog.dispose());
            buttonPanel.add(closeBtn);
            dialog.add(buttonPanel, BorderLayout.SOUTH);
            
            dialog.setVisible(true);
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading student details: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /* ---------- Set Allotment ---------- */
    void setAllotment() {
        String uname = JOptionPane.showInputDialog(this, "Enter student's username for allotment:");
        if (uname == null || uname.trim().isEmpty()) return;
        String hostel = JOptionPane.showInputDialog(this, "Hostel name:");
        if (hostel == null) return;
        String room = JOptionPane.showInputDialog(this, "Room no:");
        if (room == null) return;
        try {
            ArrayList<Allotment> list = AllotmentManager.loadAllotments();
            // replace if exists
            list.removeIf(a -> a.username.equalsIgnoreCase(uname));
            list.add(new Allotment(uname, hostel, room, "Approved"));
            AllotmentManager.saveAllotments(list);
            JOptionPane.showMessageDialog(this, "Allotment saved.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving allotment.");
            ex.printStackTrace();
        }
    }

    /* ---------- Set Fees (admin sets amount due) ---------- */
    void setFees() {
        String uname = JOptionPane.showInputDialog(this, "Enter student's username to set fee:");
        if (uname == null) return;
        String amtS = JOptionPane.showInputDialog(this, "Enter amount due (number):");
        if (amtS == null) return;
        try {
            double amt = Double.parseDouble(amtS);
            ArrayList<FeeRecord> list = FeeManager.loadFees();
            FeeRecord found = null;
            for (FeeRecord f : list) if (f.username.equalsIgnoreCase(uname)) found = f;
            if (found == null) {
                found = new FeeRecord(uname, amt);
                list.add(found);
            } else {
                found.amountDue = amt;
                found.paid = false;
            }
            FeeManager.saveFees(list);
            JOptionPane.showMessageDialog(this, "Fee updated.");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Invalid amount.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving fees.");
            ex.printStackTrace();
        }
    }

    /* ---------- Manage Leaves (approve/reject) ---------- */
    void manageLeaves() {
        ArrayList<LeaveApplication> leaves = LeaveManager.loadLeaves();
        if (leaves.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No leave applications.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (LeaveApplication l : leaves) {
            sb.append("ID: ").append(l.id).append("\nUser: ").append(l.username)
                    .append("\nFrom: ").append(l.fromDate).append(" To: ").append(l.toDate)
                    .append("\nReason: ").append(l.reason).append("\nStatus: ").append(l.status);
            if (!l.adminReply.isEmpty()) sb.append("\nReply: ").append(l.adminReply);
            sb.append("\n\n");
        }
        JTextArea ta = new JTextArea(sb.toString());
        ta.setEditable(false);
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(800, 420));
        int opt = JOptionPane.showConfirmDialog(this, sp, "Leave Applications", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opt == JOptionPane.OK_OPTION) {
            String id = JOptionPane.showInputDialog(this, "Enter Leave ID to act on:");
            if (id == null) return;
            LeaveApplication target = null;
            for (LeaveApplication l : leaves) if (l.id.equals(id)) { target = l; break; }
            if (target == null) { JOptionPane.showMessageDialog(this, "ID not found."); return; }
            String[] choices = {"Approve", "Reject", "Reply Only", "Cancel"};
            int c = JOptionPane.showOptionDialog(this, "Choose action for " + id, "Action", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, choices, choices[0]);
            if (c == 0) target.status = "Approved";
            else if (c == 1) target.status = "Rejected";
            else if (c == 2) {
                String reply = JOptionPane.showInputDialog(this, "Enter reply:");
                if (reply != null) target.adminReply = reply;
            } else return;
            try {
                LeaveManager.saveLeaves(leaves);
                JOptionPane.showMessageDialog(this, "Action saved.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving leave action.");
                ex.printStackTrace();
            }
        }
    }

    /* ---------- View Visitors ---------- */
    void viewVisitors() {
        ArrayList<VisitorEntry> vs = VisitorManager.loadVisitors();
        if (vs.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No visitor records.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (VisitorEntry v : vs) {
            sb.append("Student: ").append(v.username).append(" | Visitor: ").append(v.visitorName).append(" | At: ").append(v.dateTime).append("\n");
        }
        JTextArea ta = new JTextArea(sb.toString());
        ta.setEditable(false);
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(800, 420));
        JOptionPane.showMessageDialog(this, sp, "Visitor Log", JOptionPane.INFORMATION_MESSAGE);
    }

    /* ---------- Mark Attendance (admin) ---------- */
    void markAttendance() {
        String date = JOptionPane.showInputDialog(this, "Enter date for attendance (YYYY-MM-DD) or leave empty for today:");
        if (date == null) return;
        if (date.trim().isEmpty()) date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        ArrayList<AttendanceRecord> atts = AttendanceManager.loadAttendance();
        ArrayList<Student> studs = StudentRegistration.loadStudents();
        // For simplicity ask admin to input comma-separated usernames present
        String presentList = JOptionPane.showInputDialog(this, "Enter usernames present (comma-separated):");
        if (presentList == null) return;
        Set<String> present = new HashSet<>();
        for (String s : presentList.split(",")) if (!s.trim().isEmpty()) present.add(s.trim().toLowerCase());

        // update totals
        for (Student st : studs) {
            AttendanceRecord ar = null;
            for (AttendanceRecord a : atts) if (a.username.equalsIgnoreCase(st.username)) { ar = a; break; }
            if (ar == null) {
                ar = new AttendanceRecord(st.username);
                atts.add(ar);
            }
            ar.totalDays += 1;
            if (present.contains(st.username.toLowerCase())) ar.presentDays += 1;
        }
        try {
            AttendanceManager.saveAttendance(atts);
            JOptionPane.showMessageDialog(this, "Attendance marked for " + date);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving attendance.");
            ex.printStackTrace();
        }
    }

    /* ---------- View Complaints & Reply ---------- */
    void viewComplaints() {
        ArrayList<Complaint> list = ComplaintManager.loadComplaints();
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No complaints found.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            Complaint c = list.get(i);
            sb.append((i + 1) + ". From: " + c.from + "\nMessage: " + c.message);
            if (!c.reply.isEmpty()) sb.append("\nReply: " + c.reply);
            sb.append("\n\n");
        }
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(800, 420));
        int option = JOptionPane.showConfirmDialog(this, scrollPane, "Student Complaints",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (option == JOptionPane.OK_OPTION) {
            String input = JOptionPane.showInputDialog(this, "Enter Student Name to reply:");
            if (input != null && !input.trim().isEmpty()) {
                String reply = JOptionPane.showInputDialog(this, "Enter your reply:");
                if (reply != null && !reply.trim().isEmpty()) {
                    for (Complaint c : list) {
                        if (c.from.equalsIgnoreCase(input.trim())) {
                            c.reply = reply;
                        }
                    }
                    try {
                        ComplaintManager.saveComplaints(list);
                        JOptionPane.showMessageDialog(this, "Reply saved successfully!");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Error saving reply.");
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
}

